package com.semihsedat.exchanger.service;

import com.github.ccob.bittrex4j.BittrexExchange;
import com.github.ccob.bittrex4j.dao.MarketSummary;
import com.github.ccob.bittrex4j.dao.MarketSummaryResult;
import com.semihsedat.exchanger.dataholder.MarketDataBase;
import com.semihsedat.exchanger.model.MarketData;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PortfolioDeciderService {

    private final BittrexExchange bittrexExchange;
    private final MarketDataBase marketDataBase;


    public PortfolioDeciderService(BittrexExchange bittrexExchange, MarketDataBase marketDataBase) {
        this.bittrexExchange = bittrexExchange;
        this.marketDataBase = marketDataBase;
    }

    public void executeAutoDecideJob(){
        DoubleSummaryStatistics doubleSummaryStatistics = new DoubleSummaryStatistics();
        List<MarketSummaryResult> list = Arrays.stream(bittrexExchange.getMarketSummaries().getResult())
                .filter(marketSummaryResult -> marketSummaryResult.getSummary().getMarketName().substring(0, 3).equals("BTC"))
                .collect(Collectors.toList());
        list.forEach(marketSummaryResult -> doubleSummaryStatistics.accept(getVolumeAsBitCoinValue(marketSummaryResult.getSummary())));
        List<MarketData> marketDataList = list.stream()
                .filter(marketSummaryResult -> marketSummaryResult.getMarket().isActive())
                .filter(marketSummaryResult -> (getVolumeAsBitCoinValue(marketSummaryResult.getSummary()) / doubleSummaryStatistics.getSum()) >= 0.01)
                .map(marketSummaryResult -> new MarketData(marketSummaryResult.getSummary()))
                .collect(Collectors.toList());

        executeAdd(marketDataList);
        executeRemove(marketDataList);
    }

    private void executeAdd(List<MarketData> marketDataList){
        marketDataList.stream()
                .filter(marketData -> !marketDataBase.getMarketsOnPortfolio().contains(marketData.getMarketSummary().getMarketName()))
                .forEach(marketData -> marketDataBase.addMarketOnPortfolio(marketData.getMarketSummary().getMarketName(), marketData));
    }

    private void executeRemove(List<MarketData> marketDataList){
        Set<String> marketNameSet = marketDataList.stream()
                .map(marketData -> marketData.getMarketSummary().getMarketName())
                .collect(Collectors.toSet());

        marketDataBase.getNonLockedMarketsOnPortfolio().stream()
                .filter(s -> !marketNameSet.contains(s))
                .forEach(marketDataBase::removeMarketOnPortfolio);
    }

    private double getVolumeAsBitCoinValue(MarketSummary marketSummary){
        return marketSummary.getVolume().multiply(marketSummary.getLast()).doubleValue();
    }

}
