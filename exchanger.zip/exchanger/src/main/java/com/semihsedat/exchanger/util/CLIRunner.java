package com.semihsedat.exchanger.util;

import com.github.ccob.bittrex4j.BittrexExchange;
import com.github.ccob.bittrex4j.dao.MarketSummaryResult;
import com.github.lyhnx.bittrexapiwrapper.api.PublicApi;
import com.semihsedat.exchanger.dataholder.MarketDataBase;
import com.semihsedat.exchanger.service.PortfolioDeciderService;
import eu.verdelhan.ta4j.TimeSeries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class CLIRunner implements CommandLineRunner {

    private final static Logger LOGGER = LoggerFactory.getLogger(CLIRunner.class);

    private final PublicApi publicApi;
    private final BittrexExchange bittrexExchange;

    private final PortfolioDeciderService portfolioDeciderService;
    private final MarketDataBase marketDataBase;

    @Autowired
    public CLIRunner(PublicApi publicApi, BittrexExchange bittrexExchange, PortfolioDeciderService portfolioDeciderService, MarketDataBase marketDataBase) {
        this.publicApi = publicApi;
        this.bittrexExchange = bittrexExchange;
        this.portfolioDeciderService = portfolioDeciderService;
        this.marketDataBase = marketDataBase;
    }


    @Override
    public void run(String... strings) throws Exception {
//        //Arrays.stream(bittrexExchange.getTicks("BTC-SC", BittrexExchange.Interval.hour).getResult()).forEach(tick -> LOGGER.info(tick.getStartTime().toString()));
//        DoubleSummaryStatistics doubleSummaryStatistics = new DoubleSummaryStatistics();
//        List<MarketSummaryResult> list = Arrays.stream(bittrexExchange.getMarketSummaries().getResult()).sorted(Comparator.comparing(marketSummaryResult -> marketSummaryResult.getSummary().getVolume().multiply(marketSummaryResult.getSummary().getLast()))).filter(marketSummaryResult -> marketSummaryResult.getSummary().getMarketName().substring(0, 3).equals("BTC")).collect(Collectors.toList());
//        list.forEach(marketSummaryResult -> doubleSummaryStatistics.accept(marketSummaryResult.getSummary().getVolume().doubleValue() * marketSummaryResult.getSummary().getLast().doubleValue()));
//        //list.forEach(marketSummaryResult -> LOGGER.info("Market {},  Volume: {}",marketSummaryResult.getSummary().getMarketName(), marketSummaryResult.getSummary().getVolume().toString()));
//        LOGGER.info("Avg: {}", doubleSummaryStatistics.getAverage());
//        LOGGER.info("Count: {}", doubleSummaryStatistics.getCount());
//        LOGGER.info("Min: {}", doubleSummaryStatistics.getMin());
//        LOGGER.info("Max: {}", doubleSummaryStatistics.getMax());
//        LOGGER.info("Sum: {}", doubleSummaryStatistics.getSum());
//        DecimalFormat df = new DecimalFormat("#.##");
//        list.stream().filter(marketSummaryResult -> (marketSummaryResult.getSummary().getVolume().doubleValue() * marketSummaryResult.getSummary().getLast().doubleValue() / doubleSummaryStatistics.getSum()) >= 0.01).forEach(marketSummaryResult ->  LOGGER.info("Market : {}  -  Oran: {} - Last: {}", marketSummaryResult.getSummary().getMarketName(), df.format(marketSummaryResult.getSummary().getVolume().doubleValue() * marketSummaryResult.getSummary().getLast().doubleValue() / doubleSummaryStatistics.getSum()), marketSummaryResult.getSummary().getLast()));
        portfolioDeciderService.executeAutoDecideJob();
        marketDataBase.getPortfolios().entrySet().forEach(System.out::println);
    }
}
