package com.semihsedat.exchanger.service;

import org.springframework.stereotype.Service;

@Service
public class PortfolioUpdaterService {

    public void syncCandles(){

    }

    public void syncPortfolio(String marketName){

    }

}
