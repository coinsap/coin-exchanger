package com.semihsedat.exchanger;

import com.github.ccob.bittrex4j.BittrexExchange;
import com.github.lyhnx.bittrexapiwrapper.api.BittrexApi;
import com.github.lyhnx.bittrexapiwrapper.api.PublicApi;
import com.semihsedat.exchanger.util.MyHttpFactory;
import com.semihsedat.exchanger.util.MyRequestProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.io.IOException;

@SpringBootApplication
public class ExchangerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExchangerApplication.class, args);
	}

	@Bean
	public PublicApi publicApi(){
		return new PublicApi(new MyRequestProcessor());
	}

	@Bean
	public BittrexExchange bittrexExchange() throws IOException {
		return new BittrexExchange(5,"", "", new MyHttpFactory());
	}
}
