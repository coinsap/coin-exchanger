package com.semihsedat.exchanger.dataholder;

import com.github.ccob.bittrex4j.dao.MarketSummary;
import com.semihsedat.exchanger.model.MarketData;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class MarketDataBase {

    private static final Map<String, MarketData> portfolio = new HashMap<>();

    public Map<String, MarketData> getPortfolios(){
        return Collections.unmodifiableMap(portfolio);
    }

    public MarketData getMarketData(String marketName){
        return portfolio.get(marketName);
    }

    public void addMarketOnPortfolio(String marketName, MarketData marketData){
        portfolio.put(marketName, marketData);

        //TODO update portfolio
    }

    public void removeMarketOnPortfolio(String marketName){
        if(!getLockedMarketsOnPortfolio().contains(marketName))
            portfolio.remove(marketName);
    }

    public void updateMarketSummaryOnPortfolio(MarketSummary marketSummary){

    }

    public Set<String> getMarketsOnPortfolio(){
        return portfolio.keySet();
    }

    public Set<String> getNonLockedMarketsOnPortfolio(){
        return portfolio.entrySet().stream()
                .filter(stringMarketDataEntry -> !stringMarketDataEntry.getValue().isLocked())
                .map(Map.Entry::getKey)
                .collect(Collectors.toSet());
    }

    public Set<String> getLockedMarketsOnPortfolio(){
        return portfolio.entrySet().stream()
                .filter(stringMarketDataEntry -> stringMarketDataEntry.getValue().isLocked())
                .map(Map.Entry::getKey)
                .collect(Collectors.toSet());
    }
}
