package com.semihsedat.exchanger.util;

import com.github.ccob.bittrex4j.HttpFactory;
import com.github.signalr4j.client.Logger;
import com.github.signalr4j.client.Platform;
import com.github.signalr4j.client.hubs.HubConnection;
import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.HttpClients;

public class MyHttpFactory extends HttpFactory {
    public MyHttpFactory() {
    }

    @Override
    public HttpClient createClient() {
        HttpHost httpHost = new HttpHost("gmproxy.kfs.local", 8080);
        return HttpClients.custom().setUserAgent(Platform.getUserAgent()).setProxy(httpHost).build();
    }
}
