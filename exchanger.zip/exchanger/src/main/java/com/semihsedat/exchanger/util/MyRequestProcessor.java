package com.semihsedat.exchanger.util;

import com.github.lyhnx.bittrexapiwrapper.api.requests.*;
import com.github.lyhnx.bittrexapiwrapper.market.Currency;
import com.github.lyhnx.bittrexapiwrapper.utils.gson.BittrexCurrencyGsonTypeAdapter;
import com.github.lyhnx.bittrexapiwrapper.utils.gson.BittrexDateGsonTypeAdapter;
import com.google.gson.*;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;

import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

public class MyRequestProcessor implements RequestProcessor{
    private static final Log LOG = LogFactory.getLog(DefaultRequestProcessor.class);
    private final Gson gson;
    private final RequestErrorHandler errorHandler;

    public MyRequestProcessor() {
        this(new SimpleRequestErrorHandler());
    }

    public MyRequestProcessor(RequestErrorHandler handler) {
        this.errorHandler = handler;
        this.gson = (new GsonBuilder()).registerTypeAdapter(Date.class, BittrexDateGsonTypeAdapter.getInstance()).registerTypeAdapter(Currency.class, BittrexCurrencyGsonTypeAdapter.getInstance()).create();
    }

    public <T> T process(BittrexRequest request, Class<T> clazz) {
        LOG.debug(String.format("Processing request for %s", new Object[]{request.getUri().toString()}));

        try {
            HttpHost httpHost = new HttpHost("gmproxy.kfs.local", 8080);
            CloseableHttpClient httpClient = HttpClientBuilder.create().setProxy(httpHost).build();
            Throwable var4 = null;

            T var9;
            try {
                HttpRequestBase getRequest = this.addHeadersToRequest((HttpRequestBase)(request.getMethod() == RequestMethod.GET?new HttpGet():new HttpPost()), request);
                HttpResponse httpResponse = httpClient.execute(getRequest);
                LOG.debug(String.format("Request has processed - STATUS: %s", new Object[]{httpResponse.getStatusLine()}));
                JsonObject element = (JsonObject)(new JsonParser()).parse(IOUtils.toString(httpResponse.getEntity().getContent()));
                if(!element.get("success").getAsBoolean()) {
                    LOG.debug("Request was not successful");
                    this.errorHandler.handle(element.get("message").getAsString());
                    return null;
                }

                JsonElement jsonElement = element.get("result");
                LOG.debug(String.format("Trying to parse result to an instance of %s", new Object[]{clazz.getName()}));
                var9 = this.gson.fromJson(jsonElement, clazz);
            } catch (Throwable var20) {
                var4 = var20;
                throw var20;
            } finally {
                if(httpClient != null) {
                    if(var4 != null) {
                        try {
                            httpClient.close();
                        } catch (Throwable var19) {
                            var4.addSuppressed(var19);
                        }
                    } else {
                        httpClient.close();
                    }
                }

            }

            return var9;
        } catch (IOException var22) {
            LOG.error(String.format("Failed to execute Response for %s", new Object[]{request.getUri().toString()}), var22);
            return null;
        }
    }

    private HttpRequestBase addHeadersToRequest(HttpRequestBase httpRequest, BittrexRequest bittrexRequest) {
        HttpRequestBase httpRequestCopy = null;

        try {
            httpRequestCopy = (HttpRequestBase)httpRequest.clone();
        } catch (CloneNotSupportedException var6) {
            LOG.error("Could not copy the given instance of HttpRequestBase. Usually this shouldn't happen.", var6);
        }

        if(bittrexRequest.getHeaders().isPresent()) {
            Iterator var4 = ((Map)bittrexRequest.getHeaders().get()).entrySet().iterator();

            while(var4.hasNext()) {
                Map.Entry<String, String> header = (Map.Entry)var4.next();
                httpRequestCopy.addHeader((String)header.getKey(), (String)header.getValue());
                LOG.debug(String.format("Adding header %s: %s", new Object[]{header.getKey(), header.getValue()}));
            }
        }

        httpRequestCopy.setURI(bittrexRequest.getUri());
        return httpRequestCopy;
    }
}
