package com.semihsedat.exchanger.model;

import com.github.ccob.bittrex4j.dao.Tick;

import java.util.ArrayList;
import java.util.List;

public class Candle {

    //TODO Time series convert
    private List<Tick> candlesWithPeriod1M;
    private List<Tick> candlesWithPeriod5M;
    private List<Tick> candlesWithPeriod30M;
    private List<Tick> candlesWithPeriod1H;
    private List<Tick> candlesWithPeriod1D;

    public List<Tick> getCandlesWithPeriod1M() {
        if(null == candlesWithPeriod1M)
            return new ArrayList<>();
        return candlesWithPeriod1M;
    }

    public List<Tick> getCandlesWithPeriod5M() {
        if(null == candlesWithPeriod5M)
            return new ArrayList<>();
        return candlesWithPeriod5M;
    }

    public List<Tick> getCandlesWithPeriod30M() {
        if(null == candlesWithPeriod30M)
            return new ArrayList<>();
        return candlesWithPeriod30M;
    }

    public List<Tick> getCandlesWithPeriod1H() {
        if(null == candlesWithPeriod1H)
            return new ArrayList<>();
        return candlesWithPeriod1H;
    }

    public List<Tick> getCandlesWithPeriod1D() {
        if(null == candlesWithPeriod1D)
            return new ArrayList<>();
        return candlesWithPeriod1D;
    }

    @Override
    public String toString() {
        return "Candle{" +
                "candlesWithPeriod1M=" + candlesWithPeriod1M +
                ", candlesWithPeriod5M=" + candlesWithPeriod5M +
                ", candlesWithPeriod30M=" + candlesWithPeriod30M +
                ", candlesWithPeriod1H=" + candlesWithPeriod1H +
                ", candlesWithPeriod1D=" + candlesWithPeriod1D +
                '}';
    }
}
