package com.semihsedat.exchanger.model;

import com.github.ccob.bittrex4j.dao.MarketSummary;
import com.github.ccob.bittrex4j.dao.Tick;

import java.util.List;

public class MarketData{

    private MarketSummary marketSummary;
    private Candle candleData;
    private boolean locked;

    public MarketData(MarketSummary marketSummary) {
        this.marketSummary = marketSummary;
    }

    public MarketSummary getMarketSummary() {
        return marketSummary;
    }

    public void setMarketSummary(MarketSummary marketSummary) {
        this.marketSummary = marketSummary;
    }

    public Candle getCandleData() {
        if(null == candleData)
            return new Candle();
        return candleData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MarketData that = (MarketData) o;

        return marketSummary.getMarketName().equals(that.marketSummary.getMarketName());
    }

    @Override
    public int hashCode() {
        return marketSummary.getMarketName().hashCode();
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    @Override
    public String toString() {
        return "MarketData{" +
                "marketName=" + marketSummary.getMarketName() +
                "marketLast=" + marketSummary.getLast() +
                ", candleData=" + candleData +
                ", locked=" + locked +
                '}';
    }
}
